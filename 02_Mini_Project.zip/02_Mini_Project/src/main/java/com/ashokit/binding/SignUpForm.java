package com.ashokit.binding;

import lombok.Data;

@Data
public class SignUpForm {
    private String name;
    private String email;
    private Long phno;
}
