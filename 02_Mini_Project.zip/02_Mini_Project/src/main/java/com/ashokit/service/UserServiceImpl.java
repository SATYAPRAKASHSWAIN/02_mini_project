package com.ashokit.service;

import com.ashokit.binding.LoginForm;
import com.ashokit.binding.SignUpForm;
import com.ashokit.binding.UnlockForm;
import com.ashokit.entity.UserDtlsEntity;
import com.ashokit.repository.UserDtlRepo;
import com.ashokit.utility.EmailUtility;
import com.ashokit.utility.PwdUtility;

import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDtlRepo userDtlRepo;

	@Autowired
	private EmailUtility emailUtility;
	
	@Autowired
	private HttpSession httpSession;

	@Override
	public boolean signup(SignUpForm form) {

		UserDtlsEntity user = userDtlRepo.findByemail(form.getEmail());

//        if(user!=null){
//            return false;
//        }

		System.out.println(form.getEmail());
		System.out.println(user + "satya");

		// todo: Copy data from binding obj to entity obj.
		UserDtlsEntity entity = new UserDtlsEntity();
		BeanUtils.copyProperties(form, entity);

		// ToDo generatoe my random pwd
		String tempPassWord = PwdUtility.generatoeRandomPwd();
		entity.setPwd(tempPassWord);

		// ToDo : set acount status as locked
		entity.setAccStatus("LOCKED");

		// ToDo : insert email to unlock the account
		userDtlRepo.save(entity);

		System.out.println(entity + "chikus");

		// Todo : Sent email to unlock the account
		String to = form.getEmail();
		String subject = "Unlock Your Account ! Ashok IT !";
		StringBuffer body = new StringBuffer("");
		body.append("<h1> Use below temporary pwd to unlock your account !</h1>");
		body.append("Temporary pwd : " + tempPassWord);
		body.append("<br/>");
		body.append("<a href=\"http://localhost:8080/unlock?email=" + to + "\"> Click Here To Unlock </a>");
		emailUtility.sendEmail(to, subject, body.toString());

		return true;
	}

	@Override
	public boolean unlockAccount(UnlockForm form) {
		UserDtlsEntity entity = userDtlRepo.findByemail(form.getEmail());
		if (entity.getPwd().equals(form.getTempPwd())) {
			entity.setPwd(form.getNewPwd());
			entity.setAccStatus("UNLOCKED");
			userDtlRepo.save(entity);
			return true;
		} else {
			return false;
		}

	}

	@Override
	public String login(LoginForm form) {
		UserDtlsEntity entity = userDtlRepo.findByEmailAndPwd(form.getEmail(), form.getPwd());
//		if (entity == null) {
//			return false;
//		}
//		if(entity.getAccStatus().equals("UNLOCKED")) {
//			return true;
//		}
//		return false;
		if (entity == null) {
			return "Invalid Credentials";
		}
		if (entity.getAccStatus().equals("LOCKED")) {
			return "Your Account Locked !!!";
		}
		//create session an store use data in sessio
		httpSession.setAttribute("userId", entity.getUserId());
		
		return "Success";
	}

	@Override
	public boolean forgotPwd(String email) {
		// check record presence in db with given email
		UserDtlsEntity entity = userDtlRepo.findByemail(email);
		System.out.println(entity.getEmail());

		// if record not available sent error message
		if (entity == null) {
			return false;
		}
		// if record availabe sent pwd to email and send success messgae
		String subject = "Recover Password !!";
		String body = "Your Pwd  :: " + entity.getPwd();
		emailUtility.sendEmail(email, subject, body);
		System.out.println("success");
		return true;
	}
}
