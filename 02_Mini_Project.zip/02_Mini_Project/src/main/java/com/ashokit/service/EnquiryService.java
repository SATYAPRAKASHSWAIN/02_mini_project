package com.ashokit.service;

import com.ashokit.binding.DashboardResponse;
import com.ashokit.binding.EnquiryForm;
import com.ashokit.binding.EnquirySearchCriteria;
import com.ashokit.entity.StudentEnqEntity;

import java.util.List;

public interface EnquiryService {
	public DashboardResponse getDashboard(Integer userId);

	public List<String> getCourses();

	public List<String> getEnqStatus();

	public boolean saveEnquriry(EnquiryForm form);

	public List<StudentEnqEntity> getEnquiries();

	public List<StudentEnqEntity> getFilterEntity(EnquirySearchCriteria criteria, Integer userId);

}
