package com.ashokit.service;

import com.ashokit.binding.DashboardResponse;
import com.ashokit.binding.EnquiryForm;
import com.ashokit.binding.EnquirySearchCriteria;
import com.ashokit.entity.CoursesEntity;
import com.ashokit.entity.EnqStatusEntity;
import com.ashokit.entity.StudentEnqEntity;
import com.ashokit.entity.UserDtlsEntity;
import com.ashokit.repository.CourseRepo;
import com.ashokit.repository.EnqStatusRepo;
import com.ashokit.repository.StudentEnqRepository;
import com.ashokit.repository.UserDtlRepo;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpSession;

@Service
public class EnquiryServiceImpl implements EnquiryService {

	@Autowired
	private HttpSession session;

	@Autowired
	private UserDtlRepo userRepo;

	@Autowired
	private CourseRepo courseRepo;

	@Autowired
	private StudentEnqRepository studentEnqRepository;

	@Autowired
	private EnqStatusRepo statusRepo;

	@Override
	public DashboardResponse getDashboard(Integer userId) {
		DashboardResponse response = new DashboardResponse();

		// How to get the data based on the id
		Optional<UserDtlsEntity> findById = userRepo.findById(userId);
		if (findById.isPresent()) {
			UserDtlsEntity userDtlsEntity = findById.get();
			List<StudentEnqEntity> enqUiries = userDtlsEntity.getEnquiries();

			Integer totalcnt = enqUiries.size();
			System.out.println(totalcnt + "totalcnt");
			Integer enrolledEnq = enqUiries.stream().filter(e -> e.getEnqStatus().equals("Enrolled"))
					.collect(Collectors.toList()).size();
			System.out.println(enrolledEnq + "enrolledEnq");

			Integer lostCnt = enqUiries.stream().filter(e -> e.getEnqStatus().equals("Lost"))
					.collect(Collectors.toList()).size();
			System.out.println(lostCnt + "lostCnt");
			response.setTotalEnquriesCnt(totalcnt);
			response.setEnrolledCnt(enrolledEnq);
			response.setLostCnt(lostCnt);

		}
		return response;
	}

	@Override
	public List<String> getCourses() {
		// TODO Auto-generated method stub
		List<CoursesEntity> findAll = courseRepo.findAll();

		List<String> names = new ArrayList<>();
		for (CoursesEntity entity : findAll) {
			names.add(entity.getCourseName());
		}
		return names;
	}

	@Override
	public List<String> getEnqStatus() {
		// TODO Auto-generated method stub
		List<EnqStatusEntity> findAll = statusRepo.findAll();
		List<String> statusList = new ArrayList<>();

		for (EnqStatusEntity entity : findAll) {
			statusList.add(entity.getStatusName());
		}
		return statusList;
	}

	@Override
	public boolean saveEnquriry(EnquiryForm form) {

		StudentEnqEntity enqEntity = new StudentEnqEntity();
		BeanUtils.copyProperties(form, enqEntity);
		Integer userId = (Integer) session.getAttribute("userId");

		UserDtlsEntity userEntity = userRepo.findById(userId).get();

		enqEntity.setUser(userEntity);

		studentEnqRepository.save(enqEntity);

		return true;
	}

	@Override
	public List<StudentEnqEntity> getEnquiries() {
		Integer userId = (Integer) session.getAttribute("userId");
		Optional<UserDtlsEntity> findById = userRepo.findById(userId);
		if (findById.isPresent()) {
			UserDtlsEntity userDtlsEntity = findById.get();
			List<StudentEnqEntity> enquiries = userDtlsEntity.getEnquiries();
			return enquiries;
		}
		return null;
	}

	@Override
	public List<StudentEnqEntity> getFilterEntity(EnquirySearchCriteria criteria, Integer userId) {
		Optional<UserDtlsEntity> findById = userRepo.findById(userId);
		if (findById.isPresent()) {
			UserDtlsEntity userDtlsEntity = findById.get();
			List<StudentEnqEntity> enquiries = userDtlsEntity.getEnquiries();
			
			//filter logic
			if(null!=criteria.getCourseName() && !"".equals(criteria.getCourseName())) {
				
				  enquiries = enquiries.stream().filter(e->e.getCourseName().equals(criteria.getCourseName())).collect(Collectors.toList());				
			}
			
			if(null!=criteria.getEnqStatus() && !"".equals(criteria.getEnqStatus())) {
				 enquiries = enquiries.stream().filter(e->e.getEnqStatus().equals(criteria.getEnqStatus())).collect(Collectors.toList());
			}
			
			if(null!=criteria.getClassMode() && !"".equals(criteria.getClassMode())) {
				 enquiries = enquiries.stream().filter(e->e.getClassMode().equals(criteria.getClassMode())).collect(Collectors.toList());
			}
			
			return enquiries;
		}
		return null;
	}

}
