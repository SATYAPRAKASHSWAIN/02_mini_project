package com.ashokit.repository;

import com.ashokit.entity.UserDtlsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserDtlRepo extends JpaRepository<UserDtlsEntity,Integer> {
      UserDtlsEntity findByemail(String email);
      public UserDtlsEntity findByEmailAndPwd(String email,String pwd);
}
