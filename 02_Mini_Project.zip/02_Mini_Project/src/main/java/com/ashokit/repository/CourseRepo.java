package com.ashokit.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ashokit.entity.CoursesEntity;

public interface CourseRepo extends JpaRepository<CoursesEntity, Integer>{
	

}
