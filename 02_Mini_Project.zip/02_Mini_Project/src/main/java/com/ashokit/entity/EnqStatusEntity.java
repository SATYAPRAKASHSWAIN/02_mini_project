package com.ashokit.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name="AIT_ENQURIRY_STATUS")
public class EnqStatusEntity {
    @Id
    @GeneratedValue
    private Integer statusId;
    private String statusName;

}
