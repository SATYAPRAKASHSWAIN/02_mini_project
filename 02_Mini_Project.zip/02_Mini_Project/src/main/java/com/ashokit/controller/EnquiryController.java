package com.ashokit.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ashokit.binding.DashboardResponse;
import com.ashokit.binding.EnquiryForm;
import com.ashokit.binding.EnquirySearchCriteria;
import com.ashokit.entity.StudentEnqEntity;
import com.ashokit.repository.StudentEnqRepository;
import com.ashokit.service.EnquiryService;

@Controller
public class EnquiryController {

	@Autowired
	private EnquiryService enquiryService;

	@Autowired
	private StudentEnqRepository studentEnqRepository;

	@Autowired
	private HttpSession session;

	@GetMapping("/logout")
	public String logout() {
		session.invalidate();
		return "index";

	}

	@GetMapping("/dashboard")
	public String dashboardPage(Model model) {
		// logic to fetch data for dashboard
		Integer userId = (Integer) session.getAttribute("userId");
		DashboardResponse dashboardData = enquiryService.getDashboard(userId);

		model.addAttribute("dashboardData", dashboardData);
		return "dashboard";
	}

	@PostMapping("/addEnq")
	public String addEnquiry(@ModelAttribute("formObj") EnquiryForm formObj, Model model) {
		System.out.println(formObj + "formObj");
		// TODO : save the data

		boolean status = enquiryService.saveEnquriry(formObj);
		System.out.println(status + "status");

		if (status) {
			model.addAttribute("succMsg", "Enquiry Added!!");

		} else {

			model.addAttribute("errMsg", "Problem Occured!!");
		}

		return "add-enquiry";
	}

	@GetMapping("/enquiry")
	public String addEnquiryPage(Model model) {
		System.out.println("satya1");
		// get courses for drop down
		List<String> courses = enquiryService.getCourses();
		// get enquiries status for drop down
		List<String> enqStatuses = enquiryService.getEnqStatus();
		// create binding class obj
		EnquiryForm formObj = new EnquiryForm();

		// set data in model object
		model.addAttribute("courseNames", courses);
		model.addAttribute("enqStatusNames", enqStatuses);
		model.addAttribute("formObj", formObj);
		System.out.println("satya2");
		return "add-enquiry";
	}

	@GetMapping("/enquires")
	public String viewEnquiriePage(Model model) {
		initForm(model);
		model.addAttribute("searchForm", new EnquirySearchCriteria());
		List<StudentEnqEntity> enquiries = enquiryService.getEnquiries();
		model.addAttribute("enquiries", enquiries);
		return "view-enquiries";
	}

	private void initForm(Model model) {
		// get courses for drop down
		List<String> courses = enquiryService.getCourses();

		// get enq status for drop down
		List<String> enquiries = enquiryService.getEnqStatus();

		// create binding class obj
		EnquiryForm formObj = new EnquiryForm();

		// set data in model obj

		model.addAttribute("courseNames", courses);
		model.addAttribute("enquirises", enquiries);
		model.addAttribute("formObj", formObj);

	}

	@GetMapping("/filter-enquiries")
	public String getFilterEnqs(@RequestParam String cname, @RequestParam String mode, @RequestParam String status,
			Model model) {
		EnquirySearchCriteria criteria = new EnquirySearchCriteria();
		criteria.setCourseName(cname);
		criteria.setClassMode(mode);
		criteria.setEnqStatus(status);
		System.out.println(cname + "cname");
		System.out.println(mode + "mode");
		System.out.println(status + "status");

		Integer userId = (Integer) session.getAttribute("userId");

		List<StudentEnqEntity> filterEntity = enquiryService.getFilterEntity(criteria, userId);
		model.addAttribute("enquiries", filterEntity);
		return "filter-enquiries-page";
	}

}
