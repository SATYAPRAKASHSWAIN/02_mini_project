package com.ashokit.utility;

import org.apache.commons.lang3.RandomStringUtils;

public class PwdUtility {
    public static String generatoeRandomPwd(){
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
        String pwd = RandomStringUtils.random( 6, characters );

        return pwd;
    }

}
